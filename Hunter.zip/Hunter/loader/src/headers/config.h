#pragma once

#define HTTP_SERVER "14.225.207.79"
#define HTTP_PORT 80

#define TFTP_SERVER "14.225.207.79"
